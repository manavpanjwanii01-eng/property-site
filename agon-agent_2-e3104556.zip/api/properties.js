import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      let query = supabase.from('properties').select('*');
      
      if (req.query.id) {
        query = query.eq('id', req.query.id).single();
      } else {
        if (req.query.featured) query = query.eq('featured', req.query.featured === 'true');
        if (req.query.type) query = query.eq('type', req.query.type);
        if (req.query.location) query = query.ilike('location', `%${req.query.location}%`);
        if (req.query.minPrice) query = query.gte('price', req.query.minPrice);
        if (req.query.maxPrice) query = query.lte('price', req.query.maxPrice);
        if (req.query.furnishing) query = query.eq('furnishing', req.query.furnishing);
        
        // Sorting
        if (req.query.sort === 'price_asc') query = query.order('price', { ascending: true });
        else if (req.query.sort === 'price_desc') query = query.order('price', { ascending: false });
        else query = query.order('created_at', { ascending: false }); // newest first
      }

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    // Admin only routes
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user || user.email !== 'manavrealestatee@gmail.com') {
      return res.status(401).json({ error: 'Unauthorized admin' });
    }

    if (req.method === 'POST') {
      const { data, error } = await supabase
        .from('properties')
        .insert(req.body)
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    
    if (req.method === 'PUT') {
      const { id, ...updateData } = req.body;
      const { data, error } = await supabase
        .from('properties')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    if (req.method === 'DELETE') {
      const { id } = req.body;
      const { error } = await supabase
        .from('properties')
        .delete()
        .eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
