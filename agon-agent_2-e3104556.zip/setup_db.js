import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing env vars");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function setup() {
  const { error: e1 } = await supabase.rpc('execute_sql', {
    sql: `
      CREATE TABLE IF NOT EXISTS properties (
        id SERIAL PRIMARY KEY,
        title TEXT,
        price NUMERIC,
        location TEXT,
        type TEXT,
        furnishing TEXT,
        description TEXT,
        area NUMERIC,
        bedrooms INTEGER,
        bathrooms INTEGER,
        image_urls JSONB,
        amenities JSONB,
        featured BOOLEAN DEFAULT false,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS leads (
        id SERIAL PRIMARY KEY,
        name TEXT,
        phone TEXT,
        budget TEXT,
        requirement TEXT,
        message TEXT,
        property_id INTEGER,
        status TEXT DEFAULT 'new',
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `
  });
  
  if (e1) console.error("Error creating tables:", e1);
  else console.log("Tables created successfully");
}

setup();
