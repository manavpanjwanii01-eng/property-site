import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';

export default function BlogSection() {
  const posts = [
    {
      id: 1,
      title: "Top 5 Emerging Localities for Real Estate Investment in Indore",
      excerpt: "Discover the fastest-growing areas in Indore offering the best ROI. From Super Corridor to Mahalakshmi Nagar, find out where to invest next.",
      image: "https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "Oct 12, 2023",
      author: "Manav Team",
      category: "Investment"
    },
    {
      id: 2,
      title: "A Complete Guide to Buying Your First Home in MP",
      excerpt: "First-time homebuyer? Learn about RERA registration, stamp duty, loan processing, and the essential legal checks you must perform before buying.",
      image: "https://images.pexels.com/photos/8293778/pexels-photo-8293778.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "Sep 28, 2023",
      author: "Legal Expert",
      category: "Buying Guide"
    },
    {
      id: 3,
      title: "How to Maximize Your Property's Resale Value",
      excerpt: "Simple yet highly effective renovation and staging tips to increase the market value of your property before listing it for sale.",
      image: "https://images.pexels.com/photos/2089698/pexels-photo-2089698.jpeg?auto=compress&cs=tinysrgb&w=800",
      date: "Sep 15, 2023",
      author: "Manav Team",
      category: "Selling Tips"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">Real Estate Insights</h2>
            <p className="text-gray-500 max-w-2xl">Expert advice, market trends, and guides to help you make informed property decisions.</p>
          </div>
          <Link to="/blog" className="hidden md:flex items-center gap-2 text-orange-500 font-semibold hover:text-black transition-colors">
            View All Posts <ArrowRight className="h-5 w-5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {posts.map((post, i) => (
            <motion.article 
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all group flex flex-col"
            >
              <Link to={`/blog/${post.id}`} className="block relative aspect-[16/10] overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 text-xs font-bold text-orange-500 rounded uppercase tracking-wider">
                  {post.category}
                </div>
              </Link>
              
              <div className="p-6 flex flex-col flex-grow">
                <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5" /> {post.date}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <User className="h-3.5 w-3.5" /> {post.author}
                  </div>
                </div>
                
                <Link to={`/blog/${post.id}`}>
                  <h3 className="text-xl font-bold text-black mb-3 group-hover:text-orange-500 transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                </Link>
                
                <p className="text-gray-600 text-sm leading-relaxed mb-6 line-clamp-3 flex-grow">
                  {post.excerpt}
                </p>
                
                <Link to={`/blog/${post.id}`} className="mt-auto inline-flex items-center gap-2 text-sm font-bold text-black group-hover:text-orange-500 transition-colors">
                  Read More <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>

        <div className="mt-10 text-center md:hidden">
          <Link to="/blog" className="inline-flex items-center gap-2 text-orange-500 font-semibold hover:text-black transition-colors">
            View All Posts <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
