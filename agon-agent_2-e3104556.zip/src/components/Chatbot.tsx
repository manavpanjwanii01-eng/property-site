import { useState, useRef, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { MessageSquare, X, Send, Building2, User } from 'lucide-react';
import { collection, addDoc, getDocs, query, limit, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'framer-motion';

type Message = {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  options?: string[];
  properties?: any[];
};

export default function Chatbot() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [step, setStep] = useState('INITIAL');
  const [leadData, setLeadData] = useState({ requirement: '', type: '', budget: '', name: '', phone: '' });
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Don't show on admin panel
  if (location.pathname === '/secure-admin-portal-786') return null;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, isOpen]);

  // Initialize chat
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setIsTyping(true);
      setTimeout(() => {
        addBotMessage(
          "Hi! Welcome to Manav Real Estate. I am your virtual assistant. How can I help you today?",
          ["Looking to Buy", "Looking to Rent", "List a Property", "Contact Agent"]
        );
        setIsTyping(false);
      }, 1000);
    }
  }, [isOpen]);

  const addBotMessage = (text: string, options?: string[], properties?: any[]) => {
    setMessages(prev => [...prev, { id: Date.now().toString(), sender: 'bot', text, options, properties }]);
  };

  const addUserMessage = (text: string) => {
    setMessages(prev => [...prev, { id: Date.now().toString(), sender: 'user', text }]);
  };

  const formatPrice = (price: number) => {
    if (price >= 10000000) return `₹${(price / 10000000).toFixed(2)} Cr`;
    if (price >= 100000) return `₹${(price / 100000).toFixed(2)} Lac`;
    return `₹${price}`;
  };

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    addUserMessage(text);
    setInputText('');
    setIsTyping(true);

    // Process based on current step
    switch (step) {
      case 'LEAD_NAME':
        setLeadData(prev => ({ ...prev, name: text }));
        setStep('LEAD_PHONE');
        setTimeout(() => {
          addBotMessage(`Thanks ${text}. What is your phone number so our team can reach you?`);
          setIsTyping(false);
        }, 1000);
        break;
      case 'LEAD_PHONE':
        setLeadData(prev => ({ ...prev, phone: text }));
        setStep('SUBMITTING');
        setTimeout(() => {
          submitLead({ ...leadData, phone: text });
        }, 1000);
        break;
      default:
        setTimeout(() => {
          addBotMessage("I'm a virtual assistant. Please choose an option below or type 'Agent' to contact our team.", ["Main Menu", "Contact Agent"]);
          setStep('INITIAL');
          setIsTyping(false);
        }, 1000);
        break;
    }
  };

  const handleOptionClick = async (option: string) => {
    addUserMessage(option);
    setIsTyping(true);

    if (option === 'Main Menu') {
      setStep('INITIAL');
      setTimeout(() => {
        addBotMessage("How can I help you?", ["Looking to Buy", "Looking to Rent", "List a Property", "Contact Agent"]);
        setIsTyping(false);
      }, 1000);
      return;
    }

    if (option === 'Contact Agent' || option === 'List a Property' || option === 'Yes, please') {
      setStep('LEAD_NAME');
      if (option !== 'Yes, please') {
        setLeadData(prev => ({ ...prev, requirement: option === 'List a Property' ? 'Sell' : 'General Enquiry' }));
      }
      setTimeout(() => {
        addBotMessage("I'll arrange for an expert agent to contact you. May I have your full name?");
        setIsTyping(false);
      }, 1000);
      return;
    }

    if (option === 'No, thanks') {
      setStep('INITIAL');
      setTimeout(() => {
        addBotMessage("No problem! Let me know if you need anything else.", ["Main Menu"]);
        setIsTyping(false);
      }, 1000);
      return;
    }

    if (step === 'INITIAL' && (option === 'Looking to Buy' || option === 'Looking to Rent')) {
      setLeadData(prev => ({ ...prev, requirement: option.includes('Buy') ? 'Buy' : 'Rent' }));
      setStep('AWAITING_TYPE');
      setTimeout(() => {
        addBotMessage("What type of property are you looking for?", ["Apartment", "Villa", "Plot", "Commercial"]);
        setIsTyping(false);
      }, 1000);
      return;
    }

    if (step === 'AWAITING_TYPE') {
      setLeadData(prev => ({ ...prev, type: option }));
      setStep('AWAITING_BUDGET');
      setTimeout(() => {
        addBotMessage("What is your approximate budget?", ["Under 50 Lacs", "50 Lacs - 1 Cr", "1 Cr - 2 Cr", "Above 2 Cr"]);
        setIsTyping(false);
      }, 1000);
      return;
    }

    if (step === 'AWAITING_BUDGET') {
      setLeadData(prev => ({ ...prev, budget: option }));
      setStep('FETCHING');
      setTimeout(() => fetchPropertiesForChat(option), 1000);
      return;
    }
  };

  const fetchPropertiesForChat = async (budgetStr: string) => {
    addBotMessage("Let me check our latest listings for you...");
    try {
      const q = query(collection(db, 'properties'), orderBy('createdAt', 'desc'), limit(10));
      const snapshot = await getDocs(q);
      let props = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      
      // Filter by type client side
      props = props.filter(p => p.type === leadData.type);
      
      // Limit to top 3 matches
      props = props.slice(0, 3);
      
      setTimeout(() => {
        if (props.length > 0) {
          addBotMessage(`Here are some ${leadData.type}s that might match your criteria:`, undefined, props);
          setTimeout(() => {
            addBotMessage("Would you like our agent to contact you with more details and arrange a site visit?", ["Yes, please", "No, thanks"]);
            setStep('ASK_CONTACT');
            setIsTyping(false);
          }, 1500);
        } else {
          addBotMessage("I couldn't find exact matches right now, but our inventory updates daily. Would you like an agent to contact you when something opens up?", ["Yes, please", "No, thanks"]);
          setStep('ASK_CONTACT');
          setIsTyping(false);
        }
      }, 1500);
    } catch (error) {
      setTimeout(() => {
        addBotMessage("Sorry, I had trouble fetching properties. Would you like to speak to an agent directly?", ["Yes, please", "No, thanks"]);
        setStep('ASK_CONTACT');
        setIsTyping(false);
      }, 1000);
    }
  };

  const submitLead = async (data: any) => {
    try {
      await addDoc(collection(db, 'leads'), {
        name: data.name,
        phone: data.phone,
        requirement: data.requirement,
        budget: data.budget,
        message: `Chatbot Lead - Looking for ${data.type || 'Assistance'}`,
        status: 'new',
        createdAt: new Date().toISOString()
      });
      setIsTyping(false);
      addBotMessage("Thank You! Our team will contact you within 24 hours.");
      setStep('INITIAL');
      setTimeout(() => addBotMessage("Is there anything else I can help you with?", ["Main Menu"]), 1500);
    } catch (err) {
      setIsTyping(false);
      addBotMessage("Oops, something went wrong. Please try contacting us via the Contact page.");
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 bg-black text-white p-4 rounded-full shadow-2xl hover:scale-110 hover:bg-orange-500 transition-all duration-300 flex items-center justify-center group"
        aria-label="Open Chat"
      >
        {isOpen ? <X className="h-7 w-7" /> : <MessageSquare className="h-7 w-7" />}
        {!isOpen && (
          <span className="absolute right-full mr-4 bg-white text-black px-3 py-1.5 rounded-lg text-sm font-semibold shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Chat with Manav Real Estate
          </span>
        )}
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-6 w-96 max-w-[calc(100vw-3rem)] h-[550px] max-h-[calc(100vh-8rem)] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50 border border-gray-100"
          >
            {/* Header */}
            <div className="bg-black p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold leading-tight">Manav Real Estate</h3>
                  <p className="text-gray-400 text-xs flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-500 rounded-full inline-block"></span> Online
                  </p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex max-w-[85%] gap-2 ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    
                    {/* Avatar */}
                    <div className="shrink-0 mt-auto">
                      {msg.sender === 'bot' ? (
                        <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                          <Building2 className="w-4 h-4 text-orange-600" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Message Content */}
                    <div className="flex flex-col gap-2">
                      <div className={`px-4 py-2.5 rounded-2xl text-sm ${
                        msg.sender === 'user' 
                          ? 'bg-black text-white rounded-br-sm' 
                          : 'bg-white text-gray-800 border border-gray-100 shadow-sm rounded-bl-sm'
                      }`}>
                        {msg.text}
                      </div>

                      {/* Options */}
                      {msg.options && (
                        <div className="flex flex-col gap-2 mt-1">
                          {msg.options.map((opt, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleOptionClick(opt)}
                              className="text-left px-4 py-2 bg-white border border-orange-200 text-orange-600 text-sm rounded-xl hover:bg-orange-50 hover:border-orange-500 transition-colors shadow-sm font-medium"
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Properties */}
                      {msg.properties && msg.properties.length > 0 && (
                        <div className="flex flex-col gap-3 mt-1 w-64">
                          {msg.properties.map((p) => (
                            <Link 
                              to={`/properties/${p.id}`} 
                              key={p.id} 
                              className="block bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-orange-500 transition-colors shadow-sm"
                              onClick={() => setIsOpen(false)}
                            >
                              <div className="h-32 bg-gray-100 relative">
                                <img src={p.image_urls?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800'} alt={p.title} className="w-full h-full object-cover" />
                                <div className="absolute top-2 left-2 bg-white/90 px-2 py-0.5 text-xs font-bold rounded">
                                  {p.type}
                                </div>
                              </div>
                              <div className="p-3">
                                <h4 className="font-bold text-sm text-gray-900 line-clamp-1">{p.title}</h4>
                                <div className="flex justify-between items-center mt-1">
                                  <p className="text-orange-500 font-bold text-sm">{formatPrice(p.price)}</p>
                                  <span className="text-xs text-gray-500">{p.location}</span>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex gap-2 max-w-[85%] flex-row">
                    <div className="shrink-0 mt-auto">
                      <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                        <Building2 className="w-4 h-4 text-orange-600" />
                      </div>
                    </div>
                    <div className="px-4 py-3.5 bg-white border border-gray-100 shadow-sm rounded-2xl rounded-bl-sm flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-3 bg-white border-t border-gray-100 shrink-0">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(inputText); }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                  disabled={isTyping}
                />
                <button
                  type="submit"
                  disabled={!inputText.trim() || isTyping}
                  className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center shrink-0 hover:bg-orange-500 transition-colors disabled:opacity-50 disabled:hover:bg-black"
                >
                  <Send className="h-4 w-4 ml-0.5" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}