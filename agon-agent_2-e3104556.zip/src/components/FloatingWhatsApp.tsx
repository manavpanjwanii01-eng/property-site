import { MessageCircle } from 'lucide-react';
import { useLocation } from 'react-router-dom';

export default function FloatingWhatsApp() {
  const location = useLocation();
  if (location.pathname === '/secure-admin-portal-786') return null;

  return (
    <a
      href="https://wa.me/919131479561"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 left-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform duration-300 flex items-center justify-center"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}
