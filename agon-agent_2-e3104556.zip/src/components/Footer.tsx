import { Link, useLocation } from 'react-router-dom';
import { Building2, Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  const location = useLocation();
  if (location.pathname === '/secure-admin-portal-786') return null;

  return (
    <footer className="bg-gray-50 border-t border-gray-100 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <Building2 className="h-8 w-8 text-orange-500" />
              <div className="flex flex-col">
                <span className="font-bold text-xl tracking-tight leading-none text-black">MANAV</span>
                <span className="text-[10px] tracking-widest text-gray-500 font-medium">REAL ESTATE</span>
              </div>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              Your trusted partner for finding the perfect residential and commercial properties in Indore. We are dedicated to providing transparent, professional, and personalized real estate solutions to help you find your ideal space.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/61586085873953" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-orange-500 transition-colors"><Facebook className="h-5 w-5" /></a>
              <a href="https://instagram.com/manavrealestatee" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-orange-500 transition-colors"><Instagram className="h-5 w-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-black mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/properties" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">All Properties</Link></li>
              <li><Link to="/services" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Our Services</Link></li>
              <li><Link to="/about" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-black mb-6">Services</h4>
            <ul className="space-y-3">
              <li><Link to="/services" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Residential Sales</Link></li>
              <li><Link to="/services" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Commercial Leasing</Link></li>
              <li><Link to="/services" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Property Management</Link></li>
              <li><Link to="/services" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">Investment Consulting</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-black mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-orange-500 shrink-0" />
                <span className="text-gray-500 text-sm">MR3 Road, Mahalakshmi Nagar<br/>Indore, MP 452010</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-orange-500 shrink-0" />
                <a href="tel:+919131479561" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">+91 91314 79561</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-orange-500 shrink-0" />
                <a href="mailto:manavrealestatee@gmail.com" className="text-gray-500 hover:text-orange-500 text-sm transition-colors">manavrealestatee@gmail.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Manav Real Estate. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy-policy" className="text-gray-400 hover:text-black text-sm transition-colors">Privacy Policy</Link>
            <Link to="/terms-of-service" className="text-gray-400 hover:text-black text-sm transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
