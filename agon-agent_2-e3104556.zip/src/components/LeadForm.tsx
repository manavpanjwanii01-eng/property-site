import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'framer-motion';

interface LeadFormProps {
  propertyId?: string;
  title?: string;
  compact?: boolean;
}

export default function LeadForm({ propertyId, title = "Get in Touch", compact = false }: LeadFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    budget: '',
    requirement: propertyId ? 'Property Enquiry' : '1BHK',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    try {
      await addDoc(collection(db, 'leads'), {
        ...formData,
        property_id: propertyId || null,
        status: 'new',
        createdAt: new Date().toISOString()
      });
      setStatus('success');
      setFormData({ name: '', phone: '', budget: '', requirement: '1BHK', message: '' });
      setTimeout(() => setStatus('idle'), 5000);
    } catch (err) {
      console.error(err);
      setStatus('error');
      setTimeout(() => setStatus('idle'), 3000);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className={`bg-white border border-gray-100 rounded-xl p-6 ${!compact ? 'shadow-lg' : ''}`}
    >
      <h3 className="text-xl font-bold text-black mb-6">{title}</h3>
      
      {status === 'success' ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-green-50 text-green-700 p-6 rounded-lg text-center font-medium"
        >
          <div className="text-xl mb-2">Thank You!</div>
          <div className="text-sm">Our team will contact you within 24 hours.</div>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
            <input 
              required
              type="text" 
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-colors"
              placeholder="Your full name"
            />
          </div>
          
          <div className={`${!compact ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-4'}`}>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
              <input 
                required
                type="tel" 
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-colors"
                placeholder="Mobile number"
              />
            </div>
            {!propertyId && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Requirement</label>
                <select 
                  value={formData.requirement}
                  onChange={e => setFormData({...formData, requirement: e.target.value})}
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-colors"
                >
                  <option value="1BHK">1BHK</option>
                  <option value="2BHK">2BHK</option>
                  <option value="3BHK">3BHK</option>
                  <option value="4BHK">4BHK</option>
                  <option value="Duplex">Duplex</option>
                  <option value="Office">Office</option>
                  <option value="Shop">Shop</option>
                  <option value="Plots">Plots</option>
                  <option value="Building Lease">Building Lease</option>
                </select>
              </div>
            )}
          </div>

          {!propertyId && (
             <div>
               <label className="block text-sm font-medium text-gray-700 mb-1">Budget</label>
               <input 
                 type="text" 
                 value={formData.budget}
                 onChange={e => setFormData({...formData, budget: e.target.value})}
                 className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-colors"
                 placeholder="e.g. 50 Lacs - 1 Cr"
               />
             </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Message (Optional)</label>
            <textarea 
              rows={3}
              value={formData.message}
              onChange={e => setFormData({...formData, message: e.target.value})}
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 transition-colors resize-none"
              placeholder="Tell us what you're looking for..."
            />
          </div>

          {status === 'error' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm"
            >
              Something went wrong. Please try again.
            </motion.div>
          )}

          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit" 
            disabled={status === 'loading'}
            className="w-full bg-black hover:bg-orange-500 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {status === 'loading' ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Submit Enquiry'}
          </motion.button>
        </form>
      )}
    </motion.div>
  );
}
