import { Link } from 'react-router-dom';
import { MapPin, Bed, Bath, Square } from 'lucide-react';
import { motion } from 'framer-motion';

interface Property {
  id: string;
  title: string;
  price: number;
  location: string;
  type: string;
  image_urls: string[];
  bedrooms: number;
  bathrooms: number;
  area: number;
  furnishing: string;
}

export default function PropertyCard({ property, layout = 'grid' }: { property: Property, layout?: 'grid' | 'list' }) {
  const formatPrice = (price: number) => {
    if (price >= 10000000) return `₹${(price / 10000000).toFixed(2)} Cr`;
    if (price >= 100000) return `₹${(price / 100000).toFixed(2)} Lac`;
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  if (layout === 'list') {
    return (
      <motion.div 
        whileHover={{ y: -5, scale: 1.01 }}
        transition={{ duration: 0.2 }}
        className="group bg-white border border-gray-100 hover:border-orange-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col sm:flex-row overflow-hidden rounded-xl"
      >
        <div className="relative sm:w-1/3 aspect-[4/3] sm:aspect-auto overflow-hidden">
          <motion.img 
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.5 }}
            src={property.image_urls?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800'} 
            alt={property.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 text-xs font-semibold rounded shadow-sm text-black uppercase tracking-wider">
            {property.type}
          </div>
        </div>
        <div className="p-6 flex flex-col justify-between sm:w-2/3">
          <div>
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-xl font-bold text-black group-hover:text-orange-500 transition-colors line-clamp-1">{property.title}</h3>
              <span className="text-xl font-bold text-orange-500 whitespace-nowrap ml-4">{formatPrice(property.price)}</span>
            </div>
            <div className="flex items-center text-gray-500 text-sm mb-4">
              <MapPin className="h-4 w-4 mr-1 shrink-0" />
              <span className="truncate">{property.location}</span>
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-6">
              {property.bedrooms > 0 && (
                <div className="flex items-center gap-1.5"><Bed className="h-4 w-4 text-gray-400" /> {property.bedrooms} Beds</div>
              )}
              {property.bathrooms > 0 && (
                <div className="flex items-center gap-1.5"><Bath className="h-4 w-4 text-gray-400" /> {property.bathrooms} Baths</div>
              )}
              {property.area > 0 && (
                <div className="flex items-center gap-1.5"><Square className="h-4 w-4 text-gray-400" /> {property.area} sq.ft</div>
              )}
            </div>
          </div>
          <div className="flex items-center justify-between pt-4 border-t border-gray-50">
            <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded">{property.furnishing}</span>
            <Link to={`/properties/${property.id}`} className="text-sm font-semibold text-black hover:text-orange-500 transition-colors flex items-center gap-1">
              View Details &rarr;
            </Link>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className="group bg-white border border-gray-100 hover:border-orange-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden rounded-xl h-full"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <motion.img 
          whileHover={{ scale: 1.08 }}
          transition={{ duration: 0.6 }}
          src={property.image_urls?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800'} 
          alt={property.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 text-xs font-semibold rounded shadow-sm text-black uppercase tracking-wider">
          {property.type}
        </div>
        <div className="absolute bottom-4 right-4 bg-black/80 backdrop-blur px-3 py-1.5 text-sm font-bold rounded shadow-sm text-white">
          {formatPrice(property.price)}
        </div>
      </div>
      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-lg font-bold text-black group-hover:text-orange-500 transition-colors line-clamp-1 mb-2">{property.title}</h3>
        <div className="flex items-center text-gray-500 text-sm mb-4">
          <MapPin className="h-4 w-4 mr-1 shrink-0" />
          <span className="truncate">{property.location}</span>
        </div>
        <div className="grid grid-cols-3 gap-2 text-sm text-gray-600 mb-5 pb-5 border-b border-gray-50 mt-auto">
          {property.bedrooms > 0 && (
            <div className="flex items-center gap-1.5"><Bed className="h-4 w-4 text-gray-400" /> {property.bedrooms}</div>
          )}
          {property.bathrooms > 0 && (
            <div className="flex items-center gap-1.5"><Bath className="h-4 w-4 text-gray-400" /> {property.bathrooms}</div>
          )}
          {property.area > 0 && (
            <div className="flex items-center gap-1.5"><Square className="h-4 w-4 text-gray-400" /> {property.area}</div>
          )}
        </div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-gray-400 bg-gray-50 px-2 py-1 rounded">{property.furnishing}</span>
          <Link to={`/properties/${property.id}`} className="text-sm font-semibold text-black hover:text-orange-500 transition-colors">
            View Details &rarr;
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
