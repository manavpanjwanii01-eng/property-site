import { useState } from 'react';
import { Play, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function VideoReels() {
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  const reels = [
    {
      id: 1,
      title: "Luxury Villa Tour in Mahalakshmi Nagar",
      thumbnail: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=600",
      videoUrl: "https://player.vimeo.com/external/370331420.sd.mp4?s=d00c3b03517208d27a45fcb8c347b419736e4f3a&profile_id=164&oauth2_token_id=57447761",
      duration: "0:45"
    },
    {
      id: 2,
      title: "Modern Apartment Walkthrough",
      thumbnail: "https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=600",
      videoUrl: "https://player.vimeo.com/external/400405232.sd.mp4?s=9f3a8b276b6b7a5a8e0e64c39f214644a8dc73cd&profile_id=164&oauth2_token_id=57447761",
      duration: "1:15"
    },
    {
      id: 3,
      title: "Commercial Space in Vijay Nagar",
      thumbnail: "https://images.pexels.com/photos/269077/pexels-photo-269077.jpeg?auto=compress&cs=tinysrgb&w=600",
      videoUrl: "https://player.vimeo.com/external/400405232.sd.mp4?s=9f3a8b276b6b7a5a8e0e64c39f214644a8dc73cd&profile_id=164&oauth2_token_id=57447761", // Placeholder video
      duration: "0:50"
    },
    {
      id: 4,
      title: "Premium Plots in Scheme 140",
      thumbnail: "https://images.pexels.com/photos/1115804/pexels-photo-1115804.jpeg?auto=compress&cs=tinysrgb&w=600",
      videoUrl: "https://player.vimeo.com/external/370331420.sd.mp4?s=d00c3b03517208d27a45fcb8c347b419736e4f3a&profile_id=164&oauth2_token_id=57447761", // Placeholder video
      duration: "1:05"
    }
  ];

  return (
    <section className="py-20 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Property Tours & Reels</h2>
            <p className="text-gray-400 max-w-2xl">Experience our premium properties through immersive video walkthroughs.</p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {reels.map((reel) => (
            <motion.div 
              key={reel.id}
              whileHover={{ y: -10 }}
              className="relative aspect-[9/16] rounded-2xl overflow-hidden cursor-pointer group shadow-xl"
              onClick={() => setActiveVideo(reel.videoUrl)}
            >
              <img 
                src={reel.thumbnail} 
                alt={reel.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="w-14 h-14 bg-orange-500/90 backdrop-blur rounded-full flex items-center justify-center text-white pl-1 shadow-lg">
                  <Play className="h-6 w-6" />
                </div>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <span className="inline-block bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-medium mb-2">
                  {reel.duration}
                </span>
                <h3 className="font-bold text-sm md:text-base line-clamp-2 leading-snug">{reel.title}</h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {activeVideo && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-sm p-4"
          >
            <button 
              onClick={() => setActiveVideo(null)}
              className="absolute top-6 right-6 text-white hover:text-orange-500 p-2 bg-white/10 rounded-full transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
            
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-lg aspect-[9/16] bg-black rounded-2xl overflow-hidden shadow-2xl relative"
            >
              <video 
                src={activeVideo} 
                controls 
                autoPlay 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
