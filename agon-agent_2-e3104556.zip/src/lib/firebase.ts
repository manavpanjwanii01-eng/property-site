import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAu01qviTefHkHARCKWZx3PQNuaLcXjDP4",
  authDomain: "manavrealestate-381a6.firebaseapp.com",
  projectId: "manavrealestate-381a6",
  storageBucket: "manavrealestate-381a6.firebasestorage.app",
  messagingSenderId: "1057992268184",
  appId: "1:1057992268184:web:77cbb1a7a42380c40c73ed",
  measurementId: "G-VYJ1QHJ6Q9"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
