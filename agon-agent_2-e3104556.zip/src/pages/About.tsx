import { CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

export default function About() {
  return (
    <div className="min-h-screen bg-white overflow-hidden">
      {/* Hero */}
      <div className="relative h-[400px] flex items-center">
        <div className="absolute inset-0 z-0">
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5 }}
            src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1920" 
            alt="Office meeting" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/60"></div>
        </div>
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full"
        >
          <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl font-bold text-white mb-4">About Manav Real Estate</motion.h1>
          <motion.p variants={fadeInUp} className="text-xl text-gray-300">Building trust since 2015.</motion.p>
        </motion.div>
      </div>

      {/* Content */}
      <div className="py-20">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <div className="flex flex-col md:flex-row gap-16 items-center mb-24">
            <motion.div variants={fadeInUp} className="md:w-1/2">
              <h2 className="text-3xl font-bold text-black mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Established in 2015, Manav Real Estate has grown to become one of Indore's most trusted and respected real estate consultancy firms. We started with a simple mission: to bring transparency and professionalism to the local real estate market.
                </p>
                <p>
                  Over the years, we have helped hundreds of families find their dream homes and businesses secure their ideal commercial spaces. Our deep understanding of the Indore market, combined with our commitment to ethical practices, sets us apart.
                </p>
                <p>
                  We don't just sell properties; we build relationships. Our team of experienced professionals guides you through every step of the real estate journey, ensuring a smooth and hassle-free experience.
                </p>
              </div>
            </motion.div>
            <motion.div variants={fadeInUp} className="md:w-1/2 w-full">
              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 hover:shadow-xl transition-shadow">
                <h3 className="text-2xl font-bold text-black mb-6">Why Trust Us?</h3>
                <ul className="space-y-4">
                  {[
                    '8+ Years of Market Experience',
                    'Extensive Network in Indore',
                    'Transparent Dealings',
                    'Verified Property Listings',
                    'Expert Legal Guidance',
                    'Dedicated After-Sales Support'
                  ].map((item, i) => (
                    <motion.li 
                      key={i} 
                      whileHover={{ x: 5 }}
                      className="flex items-center gap-3"
                    >
                      <CheckCircle2 className="h-6 w-6 text-orange-500 shrink-0" />
                      <span className="font-medium text-gray-800">{item}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </motion.div>
          </div>

          {/* Founder Section */}
          <div className="flex flex-col md:flex-row-reverse gap-16 items-center">
            <motion.div variants={fadeInUp} className="md:w-1/2">
              <h2 className="text-3xl font-bold text-black mb-2">Meet Our Founder & CEO</h2>
              <h3 className="text-xl font-medium text-orange-500 mb-6">Manav Panjwani</h3>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Manav Panjwani is the Founder & CEO of Manav Real Estate, driven by a clear vision to simplify property buying and build trust in the real estate market of Indore. With a strong focus on transparency, dedication, and client satisfaction, he is committed to helping people find the right property with ease.
                </p>
                <p>
                  At Manav Real Estate, our continuous effort and hard work are focused on one goal — to become the most trusted property partner in Indore. We believe in honest dealings, personalized service, and long-term relationships with our clients.
                </p>
              </div>
            </motion.div>
            <motion.div variants={fadeInUp} className="md:w-1/2 w-full flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-orange-500 rounded-2xl transform translate-x-4 translate-y-4"></div>
                <img 
                  src="https://lh3.googleusercontent.com/p/AF1QipPG4_c84nTBHyqJoZHbElFhwVkkl0AS-OLrhaAF=s1360-w1360-h1020-rw" 
                  alt="Manav Panjwani - Founder & CEO" 
                  className="relative z-10 w-full max-w-md rounded-2xl shadow-xl object-cover aspect-[4/5]"
                />
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Stats */}
      <div className="bg-black py-16">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <motion.div variants={fadeInUp} whileHover={{ scale: 1.1 }}>
              <div className="text-4xl md:text-5xl font-black text-orange-500 mb-2">2015</div>
              <div className="text-gray-400 font-medium uppercase tracking-wide text-sm">Established</div>
            </motion.div>
            <motion.div variants={fadeInUp} whileHover={{ scale: 1.1 }}>
              <div className="text-4xl md:text-5xl font-black text-orange-500 mb-2">500+</div>
              <div className="text-gray-400 font-medium uppercase tracking-wide text-sm">Happy Clients</div>
            </motion.div>
            <motion.div variants={fadeInUp} whileHover={{ scale: 1.1 }}>
              <div className="text-4xl md:text-5xl font-black text-orange-500 mb-2">1000+</div>
              <div className="text-gray-400 font-medium uppercase tracking-wide text-sm">Properties Sold</div>
            </motion.div>
            <motion.div variants={fadeInUp} whileHover={{ scale: 1.1 }}>
              <div className="text-4xl md:text-5xl font-black text-orange-500 mb-2">15+</div>
              <div className="text-gray-400 font-medium uppercase tracking-wide text-sm">Expert Agents</div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
