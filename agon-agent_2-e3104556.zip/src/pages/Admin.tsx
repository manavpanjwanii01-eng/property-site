import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db, storage } from '../lib/firebase';
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { LogOut, Home, Users, Plus, Trash2, Edit, Loader2, X, Video } from 'lucide-react';

export default function Admin() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  
  const [activeTab, setActiveTab] = useState('properties');
  const [properties, setProperties] = useState<any[]>([]);
  const [leads, setLeads] = useState<any[]>([]);
  const [tours, setTours] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Form states
  const [showForm, setShowForm] = useState(false);
  const [showTourForm, setShowTourForm] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [imagesToUpload, setImagesToUpload] = useState<FileList | null>(null);
  
  const [tourFormData, setTourFormData] = useState({
    propertyId: '',
    videoUrl: '',
    title: ''
  });

  const [formData, setFormData] = useState({
    title: '', price: '', location: '', type: '1BHK', furnishing: 'Unfurnished',
    description: '', area: '', bedrooms: '', bathrooms: '', image_urls: [] as string[], video_urls: [] as string[], amenities: '', featured: false
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser && currentUser.email === 'manavrealestatee@gmail.com') {
        setUser(currentUser);
        fetchData();
      } else if (currentUser) {
        signOut(auth);
        setUser(null);
        navigate('/');
      } else {
        setUser(null);
      }
    });

    return () => unsubscribe();
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch Properties
      const propsSnapshot = await getDocs(collection(db, 'properties'));
      const propsData = propsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      propsData.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      setProperties(propsData);

      // Fetch Leads
      const leadsSnapshot = await getDocs(collection(db, 'leads'));
      const leadsData = leadsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      leadsData.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      setLeads(leadsData);

      // Fetch Tours
      const toursSnapshot = await getDocs(collection(db, 'property_tours'));
      const toursData = toursSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      toursData.sort((a: any, b: any) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      setTours(toursData);
    } catch (err: any) {
      console.error("Error fetching data:", err);
      alert("Error fetching data: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async () => {
    if (!imagesToUpload) return [];
    const urls = [];
    setUploading(true);
    try {
      for (let i = 0; i < imagesToUpload.length; i++) {
        const file = imagesToUpload[i];
        const storageRef = ref(storage, `properties/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(storageRef, file);
        const url = await getDownloadURL(snapshot.ref);
        urls.push(url);
      }
    } catch (err) {
      console.error("Upload error:", err);
      alert("Failed to upload some images");
    } finally {
      setUploading(false);
    }
    return urls;
  };

  const handleSaveProperty = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      let newImageUrls = [...formData.image_urls];
      if (imagesToUpload && imagesToUpload.length > 0) {
        const uploadedUrls = await handleImageUpload();
        newImageUrls = [...newImageUrls, ...uploadedUrls];
      }

      const payload = {
        title: formData.title,
        price: Number(formData.price) || 0,
        location: formData.location,
        type: formData.type,
        furnishing: formData.furnishing,
        description: formData.description,
        area: Number(formData.area) || 0,
        bedrooms: Number(formData.bedrooms) || 0,
        bathrooms: Number(formData.bathrooms) || 0,
        image_urls: newImageUrls,
        video_urls: formData.video_urls.filter(Boolean),
        amenities: typeof formData.amenities === 'string' ? formData.amenities.split(',').map(s => s.trim()).filter(Boolean) : formData.amenities,
        featured: formData.featured,
        updatedAt: new Date().toISOString()
      };

      if (editingId) {
        await updateDoc(doc(db, 'properties', editingId), payload);
      } else {
        await addDoc(collection(db, 'properties'), {
          ...payload,
          createdAt: new Date().toISOString()
        });
      }

      setShowForm(false);
      setImagesToUpload(null);
      await fetchData();
    } catch (err: any) {
      console.error(err);
      alert('Error saving property/tour: ' + (err.message || 'Unknown error. Please check Firebase permissions.'));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProperty = async (id: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return;
    try {
      await deleteDoc(doc(db, 'properties', id));
      fetchData();
    } catch (err) {
      console.error(err);
      alert("Failed to delete property");
    }
  };

  const updateLeadStatus = async (id: string, status: string) => {
    try {
      await updateDoc(doc(db, 'leads', id), { status });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const deleteLead = async (id: string) => {
    if (!confirm('Are you sure you want to delete this lead?')) return;
    try {
      await deleteDoc(doc(db, 'leads', id));
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveTour = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (editingId) {
        await updateDoc(doc(db, 'property_tours', editingId), {
          ...tourFormData,
          updatedAt: new Date().toISOString()
        });
      } else {
        await addDoc(collection(db, 'property_tours'), {
          ...tourFormData,
          createdAt: new Date().toISOString()
        });
      }
      setShowTourForm(false);
      await fetchData();
    } catch (err: any) {
      console.error(err);
      alert('Error saving tour: ' + (err.message || 'Unknown error. Please check Firebase permissions.'));
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTour = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tour?')) return;
    try {
      await deleteDoc(doc(db, 'property_tours', id));
      fetchData();
    } catch (err) {
      console.error(err);
      alert("Failed to delete tour");
    }
  };

  const editTour = (tour: any) => {
    setTourFormData({
      title: tour.title || '',
      videoUrl: tour.videoUrl || '',
      propertyId: tour.propertyId || ''
    });
    setEditingId(tour.id);
    setShowTourForm(true);
  };

  const editProperty = (prop: any) => {
    setFormData({
      title: prop.title || '', 
      price: prop.price || '', 
      location: prop.location || '', 
      type: prop.type || '1BHK', 
      furnishing: prop.furnishing || 'Unfurnished',
      description: prop.description || '', 
      area: prop.area || '', 
      bedrooms: prop.bedrooms || '', 
      bathrooms: prop.bathrooms || '',
      image_urls: prop.image_urls || [], 
      amenities: prop.amenities?.join ? prop.amenities.join(', ') : '', 
      video_urls: prop.video_urls || [],
      featured: prop.featured || false
    });
    setEditingId(prop.id);
    setNewImageUrl('');
    setShowForm(true);
  };

  const removeImage = (index: number) => {
    const newUrls = [...formData.image_urls];
    newUrls.splice(index, 1);
    setFormData({ ...formData, image_urls: newUrls });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-xl shadow-xl w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-black">Admin Portal</h1>
            <p className="text-gray-500 text-sm">Secure access only</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            {authError && <div className="bg-red-50 text-red-600 p-3 rounded text-sm">{authError}</div>}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-4 py-2 border rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full px-4 py-2 border rounded-lg" />
            </div>
            <button type="submit" className="w-full bg-black text-white py-2.5 rounded-lg font-medium hover:bg-gray-900 transition-colors">
              Login to Dashboard
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <div className="w-64 bg-black text-white p-6 flex flex-col">
        <h2 className="text-xl font-bold mb-8 text-orange-500">Manav Admin</h2>
        <nav className="space-y-2 flex-grow">
          <button onClick={() => {setActiveTab('properties'); setShowForm(false); setShowTourForm(false);}} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'properties' ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
            <Home className="h-5 w-5" /> Properties
          </button>
          <button onClick={() => {setActiveTab('tours'); setShowForm(false); setShowTourForm(false);}} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'tours' ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
            <Video className="h-5 w-5" /> Property Tours
          </button>
          <button onClick={() => {setActiveTab('leads'); setShowForm(false); setShowTourForm(false);}} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'leads' ? 'bg-white/10 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
            <Users className="h-5 w-5" /> Leads
          </button>
        </nav>
        <button onClick={handleLogout} className="flex items-center gap-3 text-gray-400 hover:text-white mt-auto py-3">
          <LogOut className="h-5 w-5" /> Logout
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          
          {activeTab === 'properties' && !showForm && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Properties</h1>
                <button onClick={() => {
                  setFormData({ title: '', price: '', location: '', type: '1BHK', furnishing: 'Unfurnished', description: '', area: '', bedrooms: '', bathrooms: '', image_urls: [], video_urls: [], amenities: '', featured: false });
                  setEditingId('');
                  setNewImageUrl('');
                  setShowForm(true);
                }} className="bg-orange-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-orange-600">
                  <Plus className="h-5 w-5" /> Add Property
                </button>
              </div>

              <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-4 font-medium text-gray-500">Title</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Location</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Price</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Type</th>
                      <th className="px-6 py-4 font-medium text-gray-500 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {properties.map((p: any) => (
                      <tr key={p.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">{p.title}</td>
                        <td className="px-6 py-4 text-gray-500">{p.location}</td>
                        <td className="px-6 py-4 text-gray-900">₹{p.price}</td>
                        <td className="px-6 py-4 text-gray-500">{p.type}</td>
                        <td className="px-6 py-4 flex justify-end gap-3">
                          <button onClick={() => editProperty(p)} className="text-blue-600 hover:text-blue-800"><Edit className="h-5 w-5" /></button>
                          <button onClick={() => handleDeleteProperty(p.id)} className="text-red-600 hover:text-red-800"><Trash2 className="h-5 w-5" /></button>
                        </td>
                      </tr>
                    ))}
                    {properties.length === 0 && <tr><td colSpan={5} className="px-6 py-8 text-center text-gray-500">No properties found</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'properties' && showForm && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">{editingId ? 'Edit Property' : 'Add Property'}</h2>
                <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-black">Cancel</button>
              </div>
              
              <form onSubmit={handleSaveProperty} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">Title *</label>
                    <input required type="text" value={formData.title} onChange={e=>setFormData({...formData, title: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Price (₹)</label>
                    <input type="number" value={formData.price} onChange={e=>setFormData({...formData, price: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Location</label>
                    <input type="text" value={formData.location} onChange={e=>setFormData({...formData, location: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <select value={formData.type} onChange={e=>setFormData({...formData, type: e.target.value})} className="w-full px-3 py-2 border rounded-lg">
                      <option value="1BHK">1BHK</option>
                      <option value="2BHK">2BHK</option>
                      <option value="3BHK">3BHK</option>
                      <option value="4BHK">4BHK</option>
                      <option value="Duplex">Duplex</option>
                      <option value="Office">Office</option>
                      <option value="Shop">Shop</option>
                      <option value="Plots">Plots</option>
                      <option value="Building Lease">Building Lease</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Furnishing</label>
                    <select value={formData.furnishing} onChange={e=>setFormData({...formData, furnishing: e.target.value})} className="w-full px-3 py-2 border rounded-lg">
                      <option value="Furnished">Furnished</option>
                      <option value="Semi-Furnished">Semi-Furnished</option>
                      <option value="Unfurnished">Unfurnished</option>
                    </select>
                  </div>
                  <div className="flex items-center mt-6">
                    <input type="checkbox" id="featured" checked={formData.featured} onChange={e=>setFormData({...formData, featured: e.target.checked})} className="w-4 h-4 text-orange-500 rounded border-gray-300 focus:ring-orange-500" />
                    <label htmlFor="featured" className="ml-2 text-sm font-medium text-gray-700">Featured Property (Shows on Homepage)</label>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-1">Area (sq.ft)</label>
                    <input type="number" value={formData.area} onChange={e=>setFormData({...formData, area: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Bedrooms</label>
                    <input type="number" value={formData.bedrooms} onChange={e=>setFormData({...formData, bedrooms: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Bathrooms</label>
                    <input type="number" value={formData.bathrooms} onChange={e=>setFormData({...formData, bathrooms: e.target.value})} className="w-full px-3 py-2 border rounded-lg" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea rows={4} value={formData.description} onChange={e=>setFormData({...formData, description: e.target.value})} className="w-full px-3 py-2 border rounded-lg"></textarea>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Amenities (comma separated)</label>
                  <input type="text" value={formData.amenities} onChange={e=>setFormData({...formData, amenities: e.target.value})} placeholder="Parking, Gym, Security" className="w-full px-3 py-2 border rounded-lg" />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Video URLs (YouTube/Instagram Reels)</label>
                  
                  {formData.video_urls.map((url, idx) => (
                    <div key={idx} className="flex gap-2 mb-2">
                      <input 
                        type="url" 
                        value={url} 
                        onChange={(e) => {
                          const newUrls = [...formData.video_urls];
                          newUrls[idx] = e.target.value;
                          setFormData({...formData, video_urls: newUrls});
                        }} 
                        placeholder="https://..." 
                        className="w-full px-3 py-2 border rounded-lg" 
                      />
                      <button 
                        type="button"
                        onClick={() => {
                          const newUrls = [...formData.video_urls];
                          newUrls.splice(idx, 1);
                          setFormData({...formData, video_urls: newUrls});
                        }}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                  
                  <button 
                    type="button"
                    onClick={() => setFormData({...formData, video_urls: [...formData.video_urls, '']})}
                    className="text-sm text-orange-500 font-medium flex items-center gap-1 mt-2 hover:text-orange-600"
                  >
                    <Plus className="h-4 w-4" /> Add Video URL
                  </button>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Video URLs (YouTube/Instagram Reels)</label>
                  
                  {formData.video_urls.map((url, idx) => (
                    <div key={idx} className="flex gap-2 mb-2">
                      <input 
                        type="url" 
                        value={url} 
                        onChange={(e) => {
                          const newUrls = [...formData.video_urls];
                          newUrls[idx] = e.target.value;
                          setFormData({...formData, video_urls: newUrls});
                        }} 
                        placeholder="https://..." 
                        className="w-full px-3 py-2 border rounded-lg" 
                      />
                      <button 
                        type="button"
                        onClick={() => {
                          const newUrls = [...formData.video_urls];
                          newUrls.splice(idx, 1);
                          setFormData({...formData, video_urls: newUrls});
                        }}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                  
                  <button 
                    type="button"
                    onClick={() => setFormData({...formData, video_urls: [...formData.video_urls, '']})}
                    className="text-sm text-orange-500 font-medium flex items-center gap-1 mt-2 hover:text-orange-600"
                  >
                    <Plus className="h-4 w-4" /> Add Video URL
                  </button>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Property Images</label>
                  
                  {/* Existing Images */}
                  {formData.image_urls.length > 0 && (
                    <div className="flex flex-wrap gap-4 mb-4">
                      {formData.image_urls.map((url, idx) => (
                        <div key={idx} className="relative w-24 h-24 rounded-lg overflow-hidden border border-gray-200">
                          <img src={url} alt="property" className="w-full h-full object-cover" />
                          <button 
                            type="button" 
                            onClick={() => removeImage(idx)}
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add New Image URL */}
                  <div className="flex gap-2">
                    <input 
                      type="url" 
                      value={newImageUrl}
                      onChange={(e) => setNewImageUrl(e.target.value)}
                      placeholder="https://example.com/image.jpg"
                      className="flex-1 px-3 py-2 border rounded-lg"
                    />
                    <button 
                      type="button"
                      onClick={() => {
                        if (newImageUrl.trim()) {
                          setFormData({ ...formData, image_urls: [...formData.image_urls, newImageUrl.trim()] });
                          setNewImageUrl('');
                        }
                      }}
                      className="bg-gray-100 px-4 py-2 rounded-lg font-medium hover:bg-gray-200"
                    >
                      Add URL
                    </button>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="bg-black text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-900 flex items-center gap-2"
                >
                  {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : null}
                  {editingId ? 'Update Property' : 'Save Property'}
                </button>
              </form>
            </div>
          )}

          {activeTab === 'tours' && !showTourForm && (
            <div>
              <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Property Tours & Reels</h1>
                <button onClick={() => {
                  setTourFormData({ title: '', videoUrl: '', propertyId: '' });
                  setEditingId('');
                  setShowTourForm(true);
                }} className="bg-orange-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-orange-600">
                  <Plus className="h-5 w-5" /> Add Tour
                </button>
              </div>

              <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-4 font-medium text-gray-500">Title</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Related Property</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Video Link</th>
                      <th className="px-6 py-4 font-medium text-gray-500 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {tours.map((t: any) => {
                      const relatedProp = properties.find(p => p.id === t.propertyId);
                      return (
                        <tr key={t.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 font-medium">{t.title}</td>
                          <td className="px-6 py-4 text-gray-500">{relatedProp ? relatedProp.title : 'Unknown Property'}</td>
                          <td className="px-6 py-4 text-gray-500">
                            <a href={t.videoUrl} target="_blank" rel="noopener noreferrer" className="text-orange-500 hover:underline truncate inline-block max-w-[200px]">
                              {t.videoUrl}
                            </a>
                          </td>
                          <td className="px-6 py-4 flex justify-end gap-3">
                            <button onClick={() => editTour(t)} className="text-blue-600 hover:text-blue-800"><Edit className="h-5 w-5" /></button>
                            <button onClick={() => handleDeleteTour(t.id)} className="text-red-600 hover:text-red-800"><Trash2 className="h-5 w-5" /></button>
                          </td>
                        </tr>
                      );
                    })}
                    {tours.length === 0 && <tr><td colSpan={4} className="px-6 py-8 text-center text-gray-500">No tours found</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'tours' && showTourForm && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">{editingId ? 'Edit Tour' : 'Add Property Tour'}</h2>
                <button onClick={() => setShowTourForm(false)} className="text-gray-500 hover:text-black">Cancel</button>
              </div>
              
              <form onSubmit={handleSaveTour} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-1">Tour Title</label>
                  <input required type="text" value={tourFormData.title} onChange={e=>setTourFormData({...tourFormData, title: e.target.value})} placeholder="e.g., Luxury Villa Walkthrough" className="w-full px-3 py-2 border rounded-lg" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Video URL (YouTube/Instagram)</label>
                  <input required type="url" value={tourFormData.videoUrl} onChange={e=>setTourFormData({...tourFormData, videoUrl: e.target.value})} placeholder="https://youtube.com/watch?v=..." className="w-full px-3 py-2 border rounded-lg" />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Select Related Property</label>
                  <select required value={tourFormData.propertyId} onChange={e=>setTourFormData({...tourFormData, propertyId: e.target.value})} className="w-full px-3 py-2 border rounded-lg">
                    <option value="" disabled>Select a property</option>
                    {properties.map(p => (
                      <option key={p.id} value={p.id}>{p.title} - {p.location}</option>
                    ))}
                  </select>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="bg-black text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-900 flex items-center gap-2"
                >
                  {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : null}
                  {editingId ? 'Update Tour' : 'Save Tour'}
                </button>
              </form>
            </div>
          )}

          {activeTab === 'leads' && (
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-8">Leads & Enquiries</h1>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-4 font-medium text-gray-500">Date</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Name</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Contact</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Details</th>
                      <th className="px-6 py-4 font-medium text-gray-500">Status</th>
                      <th className="px-6 py-4 font-medium text-gray-500 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {leads.map((l: any) => (
                      <tr key={l.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm text-gray-500">{new Date(l.createdAt).toLocaleDateString()}</td>
                        <td className="px-6 py-4 font-medium">{l.name}</td>
                        <td className="px-6 py-4 text-sm">
                          <div>{l.phone}</div>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div><span className="font-medium">Req:</span> {l.requirement}</div>
                          {l.budget && <div><span className="font-medium">Budget:</span> {l.budget}</div>}
                          {l.message && <div className="text-gray-500 truncate max-w-[200px]">{l.message}</div>}
                        </td>
                        <td className="px-6 py-4">
                          <select 
                            value={l.status || 'new'} 
                            onChange={(e) => updateLeadStatus(l.id, e.target.value)}
                            className={`text-sm rounded-full px-3 py-1 font-medium border ${l.status === 'contacted' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-yellow-50 text-yellow-700 border-yellow-200'}`}
                          >
                            <option value="new">New</option>
                            <option value="contacted">Contacted</option>
                          </select>
                        </td>
                        <td className="px-6 py-4 flex justify-end gap-3">
                          <button onClick={() => deleteLead(l.id)} className="text-red-600 hover:text-red-800"><Trash2 className="h-5 w-5" /></button>
                        </td>
                      </tr>
                    ))}
                    {leads.length === 0 && <tr><td colSpan={6} className="px-6 py-8 text-center text-gray-500">No leads found</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}