import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import LeadForm from '../components/LeadForm';

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

export default function Contact() {
  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={staggerContainer}
      className="min-h-screen bg-gray-50 py-12"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <motion.div variants={fadeInUp} className="text-center mb-16">
          <h1 className="text-4xl font-bold text-black mb-4">Contact Us</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">Have a question or want to schedule a property viewing? Get in touch with us today.</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Contact Info */}
          <motion.div variants={fadeInUp}>
            <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm mb-8 hover:shadow-md transition-shadow">
              <h2 className="text-2xl font-bold mb-8">Get in Touch</h2>
              
              <div className="space-y-6">
                <motion.div whileHover={{ x: 5 }} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center shrink-0 group hover:bg-orange-500 transition-colors">
                    <MapPin className="h-6 w-6 text-orange-500 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">Office Address</h3>
                    <p className="text-gray-600">MR3 Road, Mahalakshmi Nagar<br/>Indore, Madhya Pradesh 452010</p>
                  </div>
                </motion.div>

                <motion.div whileHover={{ x: 5 }} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center shrink-0 group hover:bg-orange-500 transition-colors">
                    <Phone className="h-6 w-6 text-orange-500 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">Phone</h3>
                    <p className="text-gray-600"><a href="tel:+919131479561" className="hover:text-orange-500 transition-colors">+91 91314 79561</a></p>
                  </div>
                </motion.div>

                <motion.div whileHover={{ x: 5 }} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center shrink-0 group hover:bg-orange-500 transition-colors">
                    <Mail className="h-6 w-6 text-orange-500 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">Email</h3>
                    <p className="text-gray-600"><a href="mailto:manavrealestatee@gmail.com" className="hover:text-orange-500 transition-colors">manavrealestatee@gmail.com</a></p>
                  </div>
                </motion.div>

                <motion.div whileHover={{ x: 5 }} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center shrink-0 group hover:bg-orange-500 transition-colors">
                    <Clock className="h-6 w-6 text-orange-500 group-hover:text-white transition-colors" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">Working Hours</h3>
                    <p className="text-gray-600">Mon - Sat: 10:00 AM - 7:00 PM</p>
                    <p className="text-gray-600">Sunday: Closed</p>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="bg-gray-200 rounded-2xl h-64 overflow-hidden border border-gray-300 flex items-center justify-center hover:opacity-90 transition-opacity cursor-pointer">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.212635291871!2d75.91231643499887!3d22.757488826193747!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39631d04dd7e7989%3A0xf09f87b23144a19f!2sManav%20Real%20Estate%20-%20ESTD.%202015!5e0!3m2!1sen!2sin!4v1777317950244!5m2!1sen!2sin" width="100%" height="100%" style={{border:0}} allowFullScreen={false} loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </motion.div>

          {/* Form */}
          <motion.div variants={fadeInUp}>
            <LeadForm title="Send us a Message" />
          </motion.div>

        </div>
      </div>
    </motion.div>
  );
}
