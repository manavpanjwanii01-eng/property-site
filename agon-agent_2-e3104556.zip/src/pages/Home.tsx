import { useState, useEffect } from 'react';
import { collection, getDocs, query, where, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Search, MapPin, Building, Home as HomeIcon, CheckCircle2, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import PropertyCard from '../components/PropertyCard';
import LeadForm from '../components/LeadForm';
// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

export default function Home() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useState({ location: '', type: '', budget: '' });
  const [featuredProperties, setFeaturedProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const q = query(
          collection(db, 'properties'), 
          where('featured', '==', true),
          limit(6)
        );
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setFeaturedProperties(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchParams.location) params.append('location', searchParams.location);
    if (searchParams.type) params.append('type', searchParams.type);
    if (searchParams.budget) {
      const [min, max] = searchParams.budget.split('-');
      if (min) params.append('minPrice', min);
      if (max) params.append('maxPrice', max);
    }
    navigate(`/properties?${params.toString()}`);
  };

  return (
    <div className="flex flex-col min-h-screen overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[85vh] min-h-[600px] flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            src="https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1920" 
            alt="Modern home exterior" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="relative z-10 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
          >
            <motion.h1 variants={fadeInUp} className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight drop-shadow-lg">
              Find the Right Property <br className="hidden md:block"/> in Indore
            </motion.h1>
            <motion.p variants={fadeInUp} className="text-lg md:text-xl text-gray-200 mb-12 max-w-2xl mx-auto drop-shadow">
              Verified homes and commercial spaces across prime locations in Indore. ESTD 2015.
            </motion.p>

            {/* Smart Search */}
            <motion.div variants={fadeInUp} className="bg-white p-3 md:p-4 rounded-2xl shadow-2xl max-w-4xl mx-auto">
              <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-3">
              <div className="flex-1 relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input 
                  type="text" 
                  placeholder="Location (e.g. Vijay Nagar)" 
                  className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/50"
                  value={searchParams.location}
                  onChange={e => setSearchParams({...searchParams, location: e.target.value})}
                />
              </div>
              <div className="flex-1 relative">
                <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
                <select 
                  className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/50 appearance-none text-gray-700"
                  value={searchParams.type}
                  onChange={e => setSearchParams({...searchParams, type: e.target.value})}
                >
                  <option value="">Property Type</option>
                  <option value="1BHK">1BHK</option>
                  <option value="2BHK">2BHK</option>
                  <option value="3BHK">3BHK</option>
                  <option value="4BHK">4BHK</option>
                  <option value="Duplex">Duplex</option>
                  <option value="Office">Office</option>
                  <option value="Shop">Shop</option>
                  <option value="Plots">Plots</option>
                  <option value="Building Lease">Building Lease</option>
                </select>
              </div>
              <div className="flex-1 relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                <select 
                  className="w-full pl-10 pr-4 py-3.5 bg-gray-50 border border-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500/50 appearance-none text-gray-700"
                  value={searchParams.budget}
                  onChange={e => setSearchParams({...searchParams, budget: e.target.value})}
                >
                  <option value="">Budget</option>
                  <option value="0-5000000">Under 50 Lacs</option>
                  <option value="5000000-10000000">50 Lacs - 1 Cr</option>
                  <option value="10000000-20000000">1 Cr - 2 Cr</option>
                  <option value="20000000-">Above 2 Cr</option>
                </select>
              </div>
              <button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3.5 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-orange-500/30">
                <Search className="h-5 w-5" /> Search
              </button>
            </form>
          </motion.div>
          
          <motion.div variants={fadeInUp} className="mt-8 flex justify-center gap-4">
             <Link to="/properties" className="bg-white/10 hover:bg-white/20 backdrop-blur text-white px-6 py-2.5 rounded-full border border-white/30 text-sm font-medium transition-all hover:scale-105">
               View All Properties
             </Link>
             <Link to="/contact" className="bg-white/10 hover:bg-white/20 backdrop-blur text-white px-6 py-2.5 rounded-full border border-white/30 text-sm font-medium transition-all hover:scale-105">
               Contact Agent
             </Link>
          </motion.div>
        </motion.div>
      </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20 bg-white">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <motion.div variants={fadeInUp} className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">Featured Properties</h2>
              <p className="text-gray-500 max-w-2xl">Handpicked premium properties in Indore's best locations.</p>
            </div>
            <Link to="/properties" className="hidden md:flex items-center gap-2 text-orange-500 font-semibold hover:text-black transition-colors">
              Explore All <ArrowRight className="h-5 w-5" />
            </Link>
          </motion.div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1,2,3].map(i => (
                <div key={i} className="animate-pulse bg-gray-100 rounded-xl aspect-[4/3]"></div>
              ))}
            </div>
          ) : (
            <motion.div variants={staggerContainer} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProperties.map((prop: any) => (
                <motion.div key={prop.id} variants={fadeInUp}>
                  <PropertyCard property={prop} />
                </motion.div>
              ))}
            </motion.div>
          )}
          
          <motion.div variants={fadeInUp} className="mt-10 text-center md:hidden">
            <Link to="/properties" className="inline-flex items-center gap-2 text-orange-500 font-semibold hover:text-black transition-colors">
              Explore All <ArrowRight className="h-5 w-5" />
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* Areas We Serve */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">Areas We Serve</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">Discover premium properties across prime locations in Indore.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            {['Anand Bazar', 'Chandralok Colony', 'Alok Nagar', 'Bengali Square', 'Scheme 140', 'Scheme 78', 'Scheme 114', 'Scheme 94', 'Gulab Bagh Colony', 'Vijay Nagar', 'Palasiya'].map((area, i) => (
              <Link key={i} to={`/location/${encodeURIComponent(area)}`} className="bg-white px-6 py-3 rounded-full border border-gray-200 shadow-sm font-medium text-gray-700 hover:border-orange-500 hover:text-orange-500 transition-colors cursor-pointer block">
                {area}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">Our Services</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">Comprehensive real estate solutions tailored to your needs.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { title: 'Buy Property', desc: 'Find your dream home from our verified listings.', icon: HomeIcon },
              { title: 'Sell Property', desc: 'Get the best market value for your property.', icon: Building },
              { title: 'Rent Property', desc: 'Premium rental options for families and bachelors.', icon: MapPin },
              { title: 'Commercial', desc: 'Office spaces, shops, and commercial plots.', icon: Building },
            ].map((service, i) => (
              <div key={i} className="bg-gray-50 p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:border-orange-200 transition-all group text-center">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-orange-500 transition-colors">
                  <service.icon className="h-8 w-8 text-orange-500 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-black mb-3">{service.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
             <Link to="/services" className="inline-block bg-black text-white px-8 py-3 rounded-lg font-bold hover:bg-orange-500 transition-colors">
               View All Services
             </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us & Lead Form */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="lg:w-1/2">
              <h2 className="text-3xl md:text-4xl font-bold text-black mb-6">Why Choose Manav Real Estate?</h2>
              <p className="text-gray-500 mb-8 leading-relaxed">
                Established in 2015, we have been helping families and businesses find their perfect space in Indore. Our transparent process and market expertise make us the preferred choice.
              </p>
              
              <div className="space-y-4 mb-10">
                {[
                  '100% Verified Properties',
                  'Zero Hidden Charges',
                  'Expert Legal Assistance',
                  'End-to-End Support',
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="h-6 w-6 text-orange-500 shrink-0" />
                    <span className="text-gray-800 font-medium">{item}</span>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-8 py-8 border-y border-gray-200">
                <div>
                  <div className="text-4xl font-black text-black mb-1">500+</div>
                  <div className="text-sm text-gray-500 font-medium uppercase tracking-wider">Happy Families</div>
                </div>
                <div>
                  <div className="text-4xl font-black text-black mb-1">8+</div>
                  <div className="text-sm text-gray-500 font-medium uppercase tracking-wider">Years Experience</div>
                </div>
              </div>
            </div>

            <div className="lg:w-1/2 w-full">
              <LeadForm title="Let us find it for you" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
