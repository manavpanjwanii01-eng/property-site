import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import PropertyCard from '../components/PropertyCard';
import { MapPin, TrendingUp, Home, ArrowLeft } from 'lucide-react';

const locationDataMap: Record<string, any> = {
  'Anand Bazar': { buy: '₹4,500 - ₹7,500', rent: '₹12,000 - ₹25,000', desc: 'A bustling commercial and residential hub with excellent connectivity and amenities.' },
  'Chandralok Colony': { buy: '₹5,000 - ₹8,000', rent: '₹15,000 - ₹30,000', desc: 'A peaceful and well-connected residential area, perfect for families.' },
  'Alok Nagar': { buy: '₹4,000 - ₹6,500', rent: '₹10,000 - ₹20,000', desc: 'An emerging neighborhood offering great value for both investors and homebuyers.' },
  'Bengali Square': { buy: '₹5,500 - ₹9,000', rent: '₹15,000 - ₹35,000', desc: 'A prime location with rapid commercial development and premium residential options.' },
  'Scheme 140': { buy: '₹6,000 - ₹10,000', rent: '₹18,000 - ₹40,000', desc: 'One of the most sought-after premium residential schemes in Indore.' },
  'Scheme 78': { buy: '₹5,500 - ₹8,500', rent: '₹15,000 - ₹30,000', desc: 'A well-established area featuring wide roads, parks, and excellent infrastructure.' },
  'Scheme 114': { buy: '₹5,000 - ₹8,000', rent: '₹14,000 - ₹28,000', desc: 'A rapidly developing sector with modern amenities and good connectivity.' },
  'Scheme 94': { buy: '₹6,500 - ₹11,000', rent: '₹20,000 - ₹45,000', desc: 'A highly premium location known for luxury housing and commercial centers.' },
  'Gulab Bagh Colony': { buy: '₹5,500 - ₹9,000', rent: '₹16,000 - ₹32,000', desc: 'An upscale, serene residential neighborhood ideal for luxury living.' },
  'Vijay Nagar': { buy: '₹7,000 - ₹12,000', rent: '₹25,000 - ₹60,000', desc: 'The commercial heart of Indore, offering premium lifestyle and business opportunities.' },
  'Palasiya': { buy: '₹8,000 - ₹15,000', rent: '₹30,000 - ₹80,000', desc: 'One of the oldest and most prestigious addresses in Indore.' }
};

export default function LocationDetail() {
  const { name } = useParams();
  const decodedName = name ? decodeURIComponent(name) : '';
  const data = locationDataMap[decodedName] || { buy: 'N/A', rent: 'N/A', desc: 'A prime location in Indore with various property options.' };
  
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'properties'));
        const allProps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
        // Filter client-side
        const filtered = allProps.filter(p => p.location?.toLowerCase().includes(decodedName.toLowerCase()));
        setProperties(filtered);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (decodedName) fetchProperties();
  }, [decodedName]);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Hero */}
      <div className="bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/" className="inline-flex items-center text-gray-400 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Home
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <MapPin className="h-8 w-8 text-orange-500" />
            <h1 className="text-4xl md:text-5xl font-bold">{decodedName}</h1>
          </div>
          <p className="text-xl text-gray-400 max-w-2xl">{data.desc}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 flex items-center gap-4">
            <div className="w-14 h-14 bg-orange-50 rounded-full flex items-center justify-center shrink-0">
              <TrendingUp className="h-7 w-7 text-orange-500" />
            </div>
            <div>
              <p className="text-gray-500 font-medium mb-1">Average Buy Rate</p>
              <p className="text-2xl font-bold text-black">{data.buy} <span className="text-sm text-gray-500 font-normal">/ sq.ft</span></p>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 flex items-center gap-4">
            <div className="w-14 h-14 bg-orange-50 rounded-full flex items-center justify-center shrink-0">
              <Home className="h-7 w-7 text-orange-500" />
            </div>
            <div>
              <p className="text-gray-500 font-medium mb-1">Average Rent Rate</p>
              <p className="text-2xl font-bold text-black">{data.rent} <span className="text-sm text-gray-500 font-normal">/ month</span></p>
            </div>
          </div>
        </div>

        {/* Properties */}
        <div>
          <h2 className="text-2xl font-bold text-black mb-6">Properties in {decodedName}</h2>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1,2,3].map(i => <div className="animate-pulse bg-gray-200 rounded-xl h-80" key={i}></div>)}
            </div>
          ) : properties.length === 0 ? (
            <div className="bg-white p-12 rounded-xl text-center border border-gray-100">
              <p className="text-gray-500 text-lg">No properties currently listed in this area.</p>
              <Link to="/contact" className="inline-block mt-4 text-orange-500 font-medium hover:underline">Contact us to find off-market properties here</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {properties.map(p => <PropertyCard key={p.id} property={p} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
