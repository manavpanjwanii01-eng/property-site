export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-gray-100">
        <h1 className="text-4xl font-bold text-black mb-8">Privacy Policy</h1>
        
        <div className="prose max-w-none text-gray-600 space-y-6">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          
          <p>
            Welcome to Manav Real Estate. We respect your privacy and are committed to protecting your personal data. 
            This privacy policy will inform you as to how we look after your personal data when you visit our website 
            and tell you about your privacy rights and how the law protects you.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">1. Information We Collect</h2>
          <p>
            We may collect, use, store and transfer different kinds of personal data about you which we have grouped together follows:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Identity Data:</strong> includes first name, last name, username or similar identifier.</li>
            <li><strong>Contact Data:</strong> includes email address and telephone numbers.</li>
            <li><strong>Requirement Data:</strong> includes your property preferences, budget, and specific requirements you share with us.</li>
            <li><strong>Usage Data:</strong> includes information about how you use our website and services.</li>
          </ul>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">2. How We Use Your Information</h2>
          <p>We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>To provide you with information about properties that match your criteria.</li>
            <li>To contact you regarding your enquiries or requests.</li>
            <li>To improve our website, products/services, marketing, and customer relationships.</li>
            <li>To comply with a legal or regulatory obligation.</li>
          </ul>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">3. Data Security</h2>
          <p>
            We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used, 
            or accessed in an unauthorized way, altered, or disclosed. In addition, we limit access to your personal data to those 
            employees, agents, contractors, and other third parties who have a business need to know.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">4. Third-Party Links</h2>
          <p>
            This website may include links to third-party websites, plug-ins, and applications. Clicking on those links or 
            enabling those connections may allow third parties to collect or share data about you. We do not control these 
            third-party websites and are not responsible for their privacy statements.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">5. Contact Details</h2>
          <p>If you have any questions about this privacy policy or our privacy practices, please contact us at:</p>
          <div className="bg-gray-50 p-4 rounded-lg mt-4">
            <p><strong>Email:</strong> <a href="mailto:manavrealestatee@gmail.com" className="text-orange-500 hover:underline">manavrealestatee@gmail.com</a></p>
            <p><strong>Phone:</strong> <a href="tel:+919131479561" className="text-orange-500 hover:underline">+91 91314 79561</a></p>
            <p><strong>Address:</strong> MR3 Road, Mahalakshmi Nagar, Indore, Madhya Pradesh 452010</p>
          </div>
        </div>
      </div>
    </div>
  );
}
