import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, LayoutGrid, List } from 'lucide-react';
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'framer-motion';
import PropertyCard from '../components/PropertyCard';

// Animation variants
const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
};

export default function Properties() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [layout, setLayout] = useState<'grid' | 'list'>('grid');
  
  // Filters state
  const [filters, setFilters] = useState({
    location: searchParams.get('location') || '',
    type: searchParams.get('type') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    furnishing: searchParams.get('furnishing') || '',
    sort: searchParams.get('sort') || 'newest',
  });

  const fetchProperties = async () => {
    setLoading(true);
    try {
      let q = query(collection(db, 'properties'));
      
      // Note: Firestore requires composite indexes for multiple where/orderBy
      // For simplicity in this demo, we'll fetch all and filter client-side
      const snapshot = await getDocs(q);
      let data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
      
      // Client-side filtering
      if (filters.location) {
        data = data.filter(p => p.location.toLowerCase().includes(filters.location.toLowerCase()));
      }
      if (filters.type) {
        data = data.filter(p => p.type === filters.type);
      }
      if (filters.furnishing) {
        data = data.filter(p => p.furnishing === filters.furnishing);
      }
      if (filters.minPrice) {
        data = data.filter(p => p.price >= Number(filters.minPrice));
      }
      if (filters.maxPrice) {
        data = data.filter(p => p.price <= Number(filters.maxPrice));
      }
      
      // Client-side sorting
      if (filters.sort === 'price_asc') {
        data.sort((a, b) => (a.price || 0) - (b.price || 0));
      } else if (filters.sort === 'price_desc') {
        data.sort((a, b) => (b.price || 0) - (a.price || 0));
      } else {
        data.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      }
      
      setProperties(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
    // Update URL
    const newParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) newParams.append(key, value);
    });
    setSearchParams(newParams, { replace: true });
  }, [filters]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-black mb-2">Property Listings</h1>
          <p className="text-gray-500">Showing {properties.length} properties matching your criteria</p>
        </motion.div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:w-1/4"
          >
            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm sticky top-24">
              <div className="flex items-center gap-2 mb-6 pb-4 border-b border-gray-100">
                <Filter className="h-5 w-5 text-orange-500" />
                <h2 className="font-bold text-lg">Filters</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                  <input 
                    type="text" 
                    name="location"
                    value={filters.location}
                    onChange={handleFilterChange}
                    placeholder="e.g. Vijay Nagar"
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/50 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Property Type</label>
                  <select 
                    name="type"
                    value={filters.type}
                    onChange={handleFilterChange}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/50 outline-none"
                  >
                    <option value="">All Types</option>
                    <option value="1BHK">1BHK</option>
                    <option value="2BHK">2BHK</option>
                    <option value="3BHK">3BHK</option>
                    <option value="4BHK">4BHK</option>
                    <option value="Duplex">Duplex</option>
                    <option value="Office">Office</option>
                    <option value="Shop">Shop</option>
                    <option value="Plots">Plots</option>
                    <option value="Building Lease">Building Lease</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Furnishing</label>
                  <select 
                    name="furnishing"
                    value={filters.furnishing}
                    onChange={handleFilterChange}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/50 outline-none"
                  >
                    <option value="">Any</option>
                    <option value="Furnished">Furnished</option>
                    <option value="Semi-Furnished">Semi-Furnished</option>
                    <option value="Unfurnished">Unfurnished</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                  <div className="flex gap-2">
                    <input 
                      type="number" 
                      name="minPrice"
                      placeholder="Min"
                      value={filters.minPrice}
                      onChange={handleFilterChange}
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/50 outline-none"
                    />
                    <input 
                      type="number" 
                      name="maxPrice"
                      placeholder="Max"
                      value={filters.maxPrice}
                      onChange={handleFilterChange}
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500/50 outline-none"
                    />
                  </div>
                </div>
                
                <button 
                  onClick={() => setFilters({ location: '', type: '', minPrice: '', maxPrice: '', furnishing: '', sort: 'newest' })}
                  className="w-full py-2 text-sm text-gray-500 hover:text-black transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            {/* Top Bar */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm mb-6 flex flex-col sm:flex-row justify-between items-center gap-4"
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-500">Sort by:</span>
                <select 
                  name="sort"
                  value={filters.sort}
                  onChange={handleFilterChange}
                  className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-orange-500/50 outline-none"
                >
                  <option value="newest">Newest First</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                </select>
              </div>
              
              <div className="flex items-center gap-2 bg-gray-50 p-1 rounded-lg border border-gray-200">
                <button 
                  onClick={() => setLayout('grid')}
                  className={`p-1.5 rounded transition-all ${layout === 'grid' ? 'bg-white shadow-sm text-orange-500 scale-105' : 'text-gray-400 hover:text-black'}`}
                >
                  <LayoutGrid className="h-5 w-5" />
                </button>
                <button 
                  onClick={() => setLayout('list')}
                  className={`p-1.5 rounded transition-all ${layout === 'list' ? 'bg-white shadow-sm text-orange-500 scale-105' : 'text-gray-400 hover:text-black'}`}
                >
                  <List className="h-5 w-5" />
                </button>
              </div>
            </motion.div>

            {/* Properties List */}
            {loading ? (
              <div className={`grid gap-6 ${layout === 'grid' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
                {[1,2,3,4].map(i => (
                  <div key={i} className="animate-pulse bg-white rounded-xl h-80 border border-gray-100"></div>
                ))}
              </div>
            ) : properties.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white p-12 rounded-xl border border-gray-100 text-center"
              >
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Filter className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-xl font-bold text-black mb-2">No properties found</h3>
                <p className="text-gray-500">Try adjusting your filters to find what you're looking for.</p>
              </motion.div>
            ) : (
              <motion.div 
                variants={staggerContainer}
                initial="hidden"
                animate="visible"
                className={`grid gap-6 ${layout === 'grid' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}
              >
                {properties.map((prop: any) => (
                  <motion.div key={prop.id} variants={fadeInUp} layout>
                    <PropertyCard property={prop} layout={layout} />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
