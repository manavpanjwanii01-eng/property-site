import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Bed, Bath, Square, Check, Share2, Phone, Calendar } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'framer-motion';
import LeadForm from '../components/LeadForm';

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

export default function PropertyDetail() {
  const { id } = useParams();
  const [property, setProperty] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        if (!id) return;
        const docRef = doc(db, 'properties', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setProperty({ id: docSnap.id, ...docSnap.data() });
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchProperty();
  }, [id]);

  const formatPrice = (price: number) => {
    if (price >= 10000000) return `₹${(price / 10000000).toFixed(2)} Cr`;
    if (price >= 100000) return `₹${(price / 100000).toFixed(2)} Lac`;
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500"></div></div>;
  }

  if (!property) {
    return <div className="min-h-screen flex items-center justify-center text-2xl font-bold">Property not found</div>;
  }

  const images = property.image_urls?.length ? property.image_urls : ['https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=1200'];

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={staggerContainer}
      className="min-h-screen bg-gray-50 py-8"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <motion.div variants={fadeInUp} className="flex flex-col md:flex-row justify-between items-start md:items-end mb-6 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="bg-orange-100 text-orange-600 px-3 py-1 text-sm font-semibold rounded-full uppercase tracking-wide">{property.type}</span>
              <span className="bg-gray-200 text-gray-700 px-3 py-1 text-sm font-semibold rounded-full">{property.furnishing}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-black mb-2">{property.title}</h1>
            <div className="flex items-center text-gray-500">
              <MapPin className="h-5 w-5 mr-1" />
              <span>{property.location}</span>
            </div>
          </div>
          <div className="flex flex-col items-start md:items-end">
            <span className="text-4xl font-black text-orange-500">{formatPrice(property.price)}</span>
            <div className="flex gap-3 mt-4">
              <button className="flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors font-medium hover:scale-105 transform">
                <Share2 className="h-4 w-4" /> Share
              </button>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Gallery */}
            <motion.div variants={fadeInUp} className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
              <div className="aspect-[16/9] relative bg-gray-100">
                <motion.img 
                  key={activeImage}
                  initial={{ opacity: 0.5 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  src={images[activeImage]} 
                  alt={property.title} 
                  className="w-full h-full object-cover" 
                />
              </div>
              {images.length > 1 && (
                <div className="flex p-4 gap-4 overflow-x-auto">
                  {images.map((img: string, idx: number) => (
                    <button 
                      key={idx} 
                      onClick={() => setActiveImage(idx)}
                      className={`relative w-24 aspect-[4/3] rounded-lg overflow-hidden shrink-0 transition-all ${activeImage === idx ? 'ring-2 ring-orange-500 ring-offset-2 scale-105' : 'opacity-70 hover:opacity-100 hover:scale-105'}`}
                    >
                      <img src={img} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Quick Info */}
            <motion.div variants={fadeInUp} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-orange-50 transition-colors group">
                <Bed className="h-8 w-8 text-gray-400 mb-2 group-hover:text-orange-500 transition-colors" />
                <span className="font-bold text-lg">{property.bedrooms}</span>
                <span className="text-sm text-gray-500">Bedrooms</span>
              </div>
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-orange-50 transition-colors group">
                <Bath className="h-8 w-8 text-gray-400 mb-2 group-hover:text-orange-500 transition-colors" />
                <span className="font-bold text-lg">{property.bathrooms}</span>
                <span className="text-sm text-gray-500">Bathrooms</span>
              </div>
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-orange-50 transition-colors group">
                <Square className="h-8 w-8 text-gray-400 mb-2 group-hover:text-orange-500 transition-colors" />
                <span className="font-bold text-lg">{property.area}</span>
                <span className="text-sm text-gray-500">Sq. Ft.</span>
              </div>
              <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-orange-50 transition-colors group">
                <Calendar className="h-8 w-8 text-gray-400 mb-2 group-hover:text-orange-500 transition-colors" />
                <span className="font-bold text-lg">{new Date(property.createdAt || property.created_at || Date.now()).getFullYear()}</span>
                <span className="text-sm text-gray-500">Listed</span>
              </div>
            </motion.div>

            {/* Description */}
            <motion.div variants={fadeInUp} className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
              <h2 className="text-2xl font-bold mb-4">Description</h2>
              <div className="prose max-w-none text-gray-600 leading-relaxed whitespace-pre-wrap">
                {property.description}
              </div>
            </motion.div>

            {/* Amenities */}
            {property.amenities && property.amenities.length > 0 && (
              <motion.div variants={fadeInUp} className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
                <h2 className="text-2xl font-bold mb-6">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {property.amenities.map((amenity: string, idx: number) => (
                    <motion.div 
                      key={idx} 
                      whileHover={{ x: 5 }}
                      className="flex items-center gap-3"
                    >
                      <div className="bg-green-50 p-1 rounded-full">
                        <Check className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-gray-700 font-medium">{amenity}</span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <motion.div variants={fadeInUp} className="lg:col-span-1 space-y-6">
            <div className="sticky top-24">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
                <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-100">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center text-orange-500 font-bold text-xl">
                    MR
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Manav Real Estate</h3>
                    <p className="text-sm text-gray-500">Verified Agent</p>
                  </div>
                </div>
                
                <a href="tel:+919131479561" className="w-full bg-black hover:bg-gray-800 text-white font-medium py-3 rounded-lg transition-all hover:scale-105 flex items-center justify-center gap-2 mb-4">
                  <Phone className="h-5 w-5" /> Call Agent
                </a>
              </div>

              <LeadForm propertyId={property.id} title="Enquire About This Property" />
            </div>
          </motion.div>

        </div>
      </div>
    </motion.div>
  );
}
