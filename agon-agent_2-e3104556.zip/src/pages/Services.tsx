import { Building, Home, Key, MapPin, Briefcase, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

export default function Services() {
  const services = [
    {
      icon: Home,
      title: "Residential Sales",
      desc: "Find your dream home with our extensive portfolio of verified residential properties. Whether you are looking for luxury villas, modern apartments, or affordable family homes, our experts guide you through every step of the buying process. We provide comprehensive property tours, neighborhood insights, and negotiation support to ensure you get the best value."
    },
    {
      icon: Briefcase,
      title: "Commercial Spaces",
      desc: "Prime office spaces, retail shops, and commercial plots designed to give your business the perfect address. We understand that location is critical for business success. Our commercial real estate team helps you identify high-footfall retail spaces, state-of-the-art office buildings, and industrial plots that align with your business goals and budget."
    },
    {
      icon: Key,
      title: "Rental & Leasing",
      desc: "Hassle-free renting process for both tenants and landlords with complete documentation support. We bridge the gap between property owners seeking reliable tenants and individuals looking for comfortable rental homes or commercial leases. Our services include tenant screening, rent negotiation, agreement drafting, and ongoing property support."
    },
    {
      icon: MapPin,
      title: "Land & Plots",
      desc: "Invest in high-growth potential plots for residential building or future investment purposes. Purchasing land requires careful due diligence. We offer a curated selection of clear-title plots in rapidly developing areas like Mahalakshmi Nagar. We assist with zoning checks, legal verification, and future valuation estimates."
    },
    {
      icon: Building,
      title: "Property Management",
      desc: "Comprehensive management services for NRI and outstation owners, ensuring your property is well-maintained. Distance shouldn't prevent you from earning returns on your investment. We handle tenant sourcing, rent collection, routine maintenance, emergency repairs, and legal compliance, giving you complete peace of mind."
    },
    {
      icon: ShieldCheck,
      title: "Legal Assistance",
      desc: "Expert guidance on property laws, clear titles, registration, and complete paperwork assistance. Real estate transactions involve complex legalities. Our in-house legal advisors ensure that every property you buy or sell has a clear title, is free of encumbrances, and complies with all local municipal regulations. We handle the registry and mutation process seamlessly."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-black text-white py-20">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
        >
          <motion.h1 variants={fadeInUp} className="text-4xl md:text-5xl font-bold mb-6">Our Services</motion.h1>
          <motion.p variants={fadeInUp} className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            Comprehensive real estate solutions backed by years of market expertise in Indore. We are committed to providing transparent, professional, and personalized services to meet all your real estate needs.
          </motion.p>
        </motion.div>
      </div>

      {/* Services Grid */}
      <div className="py-20">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={staggerContainer}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-12">
            {services.map((service, idx) => (
              <motion.div 
                key={idx} 
                variants={fadeInUp}
                whileHover={{ y: -8, scale: 1.02 }}
                className="bg-gray-50 rounded-2xl p-10 border border-gray-100 hover:border-orange-500 transition-colors group"
              >
                <div className="w-16 h-16 bg-white rounded-xl shadow-sm flex items-center justify-center mb-8 group-hover:bg-orange-500 transition-colors">
                  <service.icon className="h-8 w-8 text-orange-500 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-2xl font-bold text-black mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  {service.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* CTA */}
      <div className="bg-orange-500 py-16">
        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="max-w-4xl mx-auto px-4 text-center"
        >
          <motion.h2 variants={fadeInUp} className="text-3xl font-bold text-white mb-6">Need expert advice for your property?</motion.h2>
          <motion.p variants={fadeInUp} className="text-orange-100 mb-8 text-lg">Our team of experienced consultants is ready to help you make the right choice.</motion.p>
          <motion.a 
            variants={fadeInUp}
            whileHover={{ scale: 1.05 }}
            href="/contact" 
            className="inline-block bg-black text-white px-8 py-4 rounded-lg font-bold hover:bg-gray-900 transition-colors"
          >
            Consult With Us Today
          </motion.a>
        </motion.div>
      </div>
    </div>
  );
}
