export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-gray-100">
        <h1 className="text-4xl font-bold text-black mb-8">Terms of Service</h1>
        
        <div className="prose max-w-none text-gray-600 space-y-6">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          
          <p>
            Please read these terms of service ("Terms", "Terms of Service") carefully before using the 
            Manav Real Estate website operated by Manav Real Estate ("us", "we", or "our").
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">1. Acceptance of Terms</h2>
          <p>
            By accessing or using our website and services, you agree to be bound by these Terms. 
            If you disagree with any part of the terms, then you may not access the service.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">2. Property Information</h2>
          <p>
            While we strive to provide accurate and up-to-date information regarding properties listed on our platform:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Property details, pricing, and availability are subject to change without notice.</li>
            <li>Images and floor plans are for illustrative purposes only and may not exactly represent the final property.</li>
            <li>We recommend independent verification of all property details before making any financial commitments.</li>
          </ul>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">3. User Responsibilities</h2>
          <p>As a user of our platform, you agree not to:</p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Submit false, inaccurate, or misleading information through our forms.</li>
            <li>Use the platform for any illegal or unauthorized purpose.</li>
            <li>Attempt to gain unauthorized access to our administrative systems or user data.</li>
            <li>Reproduce, duplicate, copy, or exploit any portion of the Service without express written permission.</li>
          </ul>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">4. Brokerage & Fees</h2>
          <p>
            Manav Real Estate operates as a professional real estate consultancy. Brokerage fees and service charges 
            apply to successful transactions (buying, selling, or renting) facilitated by our team. These terms will be 
            discussed and agreed upon in writing before any transaction is finalized.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">5. Limitation of Liability</h2>
          <p>
            In no event shall Manav Real Estate, nor its directors, employees, partners, agents, suppliers, or affiliates, 
            be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, 
            loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or 
            inability to access or use the Service.
          </p>

          <h2 className="text-2xl font-bold text-black mt-8 mb-4">6. Contact Us</h2>
          <p>If you have any questions about these Terms, please contact us:</p>
          <div className="bg-gray-50 p-4 rounded-lg mt-4">
            <p><strong>Email:</strong> <a href="mailto:manavrealestatee@gmail.com" className="text-orange-500 hover:underline">manavrealestatee@gmail.com</a></p>
            <p><strong>Phone:</strong> <a href="tel:+919131479561" className="text-orange-500 hover:underline">+91 91314 79561</a></p>
            <p><strong>Address:</strong> MR3 Road, Mahalakshmi Nagar, Indore, Madhya Pradesh 452010</p>
          </div>
        </div>
      </div>
    </div>
  );
}
